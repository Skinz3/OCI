class Session{
    static user = undefined;
    
}